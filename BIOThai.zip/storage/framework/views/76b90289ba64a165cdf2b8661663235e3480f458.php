<?php $__env->startSection('style'); ?>
   <link rel="stylesheet" href="<?php echo e(asset('css/asc_static.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>	
	<div class="container" style="min-height: 65vh;">
		<h2 class="display-4 text-capitalize font-weight-bold"><?php echo e($tt->title); ?></h2>
		<p class="text-mute">Ngày đăng: <?php echo e($tt->created_at); ?></p>
		<hr class="mx-3">
		<div class="row">
			<div class="col-md-6 col-sm-12 ">
				<img class="rounded img-fluid d-block mx-auto" src="<?php if($tt->picture==""): ?><?php echo e('img/no_image.svg'); ?><?php else: ?><?php echo e('upload/news/'.$tt->picture); ?><?php endif; ?>" alt="">
			</div>
			<div class="col-md-6 col-sm-12 font-weight-bold">
				<?php echo e($tt->summary); ?>

			</div>
		</div>
		<hr class="mx-3">
		<div class="container-fluid px-3">
			<?php echo $tt->content; ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
   <?php echo e($cauhinh->get('title')->value); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>