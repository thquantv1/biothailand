<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Thành Viên
                    <small> - Thêm</small>
                </h1>
            </div>
            <!-- /.col-lg-12 -->
            <div class="col-lg-12" style="padding-bottom:120px">

                <?php if(count($errors)>0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger">
                            <?php echo e($err); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(session('notice')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notice')); ?>

                </div>
                <?php endif; ?>

                <form action="<?php echo e(route('ThanhVien_edit',[$mem->id])); ?>" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="form-group<?php echo e($errors->has('ten') ? ' has-error' : ''); ?> row">
                        <?php echo Form::label('ten', 'Tên', ['class' => 'col-sm-3 control-label']); ?>

                        <div class="col-sm-9">
                            <?php echo Form::text('ten',$mem->ten, ['class' => 'form-control', 'required' => 'required']); ?>

                            <small class="text-danger"><?php echo e($errors->first('ten')); ?></small>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3">Hình ảnh</label>
                        <div class="col-sm-9">
                          <input id="picture" name="hinh" type="file" class="form-control " data-show-preview="false">
                          <img id="photo_review" class="img-responsive img-thumbnail quick-review" 
                            <?php if($mem->hinh!=""): ?>
                              src="<?php echo e(asset('upload/member/'.$mem->hinh)); ?>"
                            <?php endif; ?>
                          >
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('chucvu') ? ' has-error' : ''); ?> row">
                        <?php echo Form::label('chucvu', 'Chức Vụ', ['class' => 'col-sm-3 control-label']); ?>

                        <div class="col-sm-9">
                            <?php echo Form::text('chucvu', $mem->chucvu, ['class' => 'form-control', 'required' => 'required']); ?>

                            <small class="text-danger"><?php echo e($errors->first('chucvu')); ?></small>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('thongtin') ? ' has-error' : ''); ?> row">
                        <?php echo Form::label('thongtin', 'Thông Tin', ['class' => 'col-sm-3 control-label']); ?>

                        <div class="col-sm-9">
                            <?php echo Form::text('thongtin', $mem->thongtin, ['class' => 'form-control', 'required' => 'required']); ?>

                            <small class="text-danger"><?php echo e($errors->first('thongtin')); ?></small>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('fblink') ? ' has-error' : ''); ?> row">
                        <?php echo Form::label('fblink', 'FaceBook Link', ['class' => 'col-sm-3 control-label']); ?>

                        <div class="col-sm-9">
                            <?php echo Form::text('fblink', $mem->fblink, ['class' => 'form-control']); ?>

                            <small class="text-danger"><?php echo e($errors->first('fblink')); ?></small>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('twlink') ? ' has-error' : ''); ?> row">
                        <?php echo Form::label('twlink', 'Twitter Link', ['class' => 'col-sm-3 control-label']); ?>

                        <div class="col-sm-9">
                            <?php echo Form::text('twlink', $mem->twlink, ['class' => 'form-control']); ?>

                            <small class="text-danger"><?php echo e($errors->first('twlink')); ?></small>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('iglink') ? ' has-error' : ''); ?> row">
                        <?php echo Form::label('iglink', 'Instagram Link', ['class' => 'col-sm-3 control-label']); ?>

                        <div class="col-sm-9">
                            <?php echo Form::text('iglink', $mem->iglink, ['class' => 'form-control']); ?>

                            <small class="text-danger"><?php echo e($errors->first('iglink')); ?></small>
                        </div>
                    </div>
                    <div class="btn-group float-right">
                    <button type="submit" class="btn btn-success">Add</button>
                    <button type="reset" class="btn btn-warning">Reset</button>
                </div>
                <form>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script >
    $(document).ready(function()
    {

        $("#picture").change(function()
        {
            if(checkImage(this))
                 readURL(this,$('#photo_review'));
            else
             this.value="";

        });
    });

   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>