<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class News extends Model
{
    protected $table='news';
    public function NewsType()
    {
        return $this->belongsTo('App\NewsType','id_newstype','id');
    }
}
