<section class="bg-light" id="team">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h2 class="section-heading text-uppercase">Các Thành viên</h2>
          
        </div>
      </div>
      <div class="row">
        <?php $__currentLoopData = $dsthanhvien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-4">
          <div class="team-member">
            <img class="mx-auto rounded-circle" src="
            <?php if($mem->hinh==""): ?>
              <?php echo e(asset('img/no_image.svg')); ?>

              <?php else: ?>
              <?php echo e(asset('upload/member/'.$mem->hinh)); ?>

            <?php endif; ?>

            " alt="">
            <h4><?php echo e($mem->ten); ?></h4>
            <p class="text-muted"><?php echo e($mem->chucvu); ?></p>
            <p class="text-muted"><?php echo e($mem->thongtin); ?></p>
            <ul class="list-inline social-buttons">
              <li class="list-inline-item">
                <a href="<?php echo e($mem->twlink); ?>">
                  <i class="fab fa-twitter"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="<?php echo e($mem->fblink); ?>">
                  <i class="fab fa-facebook-f"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="<?php echo e($mem->iglink); ?>">
                  <i class="fab fa-linkedin-in"></i>
                </a>
              </li>
            </ul>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>

    </div>
  </section>
