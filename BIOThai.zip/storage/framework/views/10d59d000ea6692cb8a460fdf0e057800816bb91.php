<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Dòng Thời Gian
                    <small> - Thêm</small>
                </h1>
            </div>
            <!-- /.col-lg-12 -->
            <div class="col-lg-12" style="padding-bottom:120px">

                <?php if(count($errors)>0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger">
                            <?php echo e($err); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(session('notice')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notice')); ?>

                </div>
                <?php endif; ?>

                <form action="<?php echo e(route('Story_edit',[$st->id])); ?>" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                    <div class="form-group<?php echo e($errors->has('thoigian') ? ' has-error' : ''); ?> row " >
                        <?php echo Form::label('thoigian', 'Thời Gian', ['class' => 'col-sm-3 control-label']); ?>

                        <div class="col-sm-9">
                            <?php echo Form::date('thoigian', $st->thoigian, ['class' => 'form-control', 'required' => 'required']); ?>

                            <small class="text-danger"><?php echo e($errors->first('thoigian')); ?></small>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('tieude') ? ' has-error' : ''); ?> row">
                        <?php echo Form::label('tieude', 'Tiêu Đề', ['class' => 'col-sm-3 control-label']); ?>

                        <div class="col-sm-9">
                            <?php echo Form::text('tieude', $st->tieude, ['class' => 'form-control', 'required' => 'required']); ?>

                            <small class="text-danger"><?php echo e($errors->first('tieude')); ?></small>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-3">Hình ảnh</label>
                        <div class="col-sm-9">
                          <input id="picture" name="hinh" type="file" class="form-control " data-show-preview="false">
                          <img id="photo_review" class="img-responsive img-thumbnail quick-review"

                          <?php if($st->hinh!=""): ?>
                              src="<?php echo e(asset('upload/story/'.$st->hinh)); ?>"
                          <?php endif; ?>
                            >
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('sukien') ? ' has-error' : ''); ?> row">
                       <?php echo Form::label('sukien', 'Sự Kiện', ['class' => 'col-sm-3 control-label']); ?>

                       <div class="col-sm-9">
                           <?php echo Form::text('sukien', $st->sukien, ['class' => 'form-control', 'required' => 'required']); ?>

                           <small class="text-danger"><?php echo e($errors->first('sukien')); ?></small>
                       </div>
                    </div>

                    <div class="btn-group float-right">
                    <button type="submit" class="btn btn-success">Edit</button>
                    <button type="reset" class="btn btn-warning">Reset</button>
                </div>
                <form>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script >
    $(document).ready(function()
    {

        $("#picture").change(function()
        {
            if(checkImage(this))
                 readURL(this,$('#photo_review'));
            else
             this.value="";

        });
    });

   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>