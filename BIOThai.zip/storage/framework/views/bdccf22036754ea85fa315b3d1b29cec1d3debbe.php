<?php $__env->startSection('content'); ?>
<div class="container-fluid dknqform">
	<div id="carouselControls" class="carousel slide" data-ride="carousel" data-interval="false" data-wrap="false">
		<div class="carousel-inner">
			<div class="carousel-item active hide_prev " >
				
				<div class="card py-3 ">		      			
					<div class="card-block">
						<h4 class="card-title text-center"><?php echo e($data1->tieude); ?></h4>
						<div class="card-body"><?php echo $data1->noidung; ?></div>		      				
					</div>
				</div>
			</div>
			<div class="carousel-item">
				
				<div class="card py-3 ">		      			
					<div class="card-block">
						<h4 class="card-title text-center"><?php echo e($data2->tieude); ?></h4>
						<div class="card-body"><?php echo $data2->noidung; ?></div>		      				
					</div>
				</div>
			</div>
			<div class="carousel-item">
				
				<div class="card py-3 " id="formlienhe">
					<h4 class="card-title text-center">Đăng Ký Nhượng Quyền</h4>
					<h4 class="card-title text-center"><?php echo e('Tại '.$qh->name.'-'.$qh->TinhThanhPho->name); ?></h4>
					<p class="text-muted text-center">Vui lòng nhập đầy đủ thông tin bên dưới</p>
					<form id="DKNQ" name="sentMessage" method="POST" action="<?php echo e(route('formdknq')); ?>">
						<?php echo csrf_field(); ?>
						<?php echo Form::hidden('diachi', $qh->name.'-'.$qh->TinhThanhPho->name); ?>

						<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?> row px-2">
						    <?php echo Form::label('name', 'Tên', ['class' => 'col-sm-3 control-label text-right']); ?>

							<div class="col-sm-9">
						    	<?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required','placeholder'=>'Họ và tên','autocomplete'=>'off']); ?>

						    	<small class="text-danger"><?php echo e($errors->first('name')); ?></small>
							</div>
						</div>
						<div class="form-group<?php echo e($errors->has('cmnd') ? ' has-error' : ''); ?> row px-2">
						    <?php echo Form::label('cmnd', 'Số CMND', ['class' => 'col-sm-3 control-label text-right']); ?>

							<div class="col-sm-9">
						    	<?php echo Form::number('cmnd', null, ['class' => 'form-control', 'required' => 'required','placeholder'=>'số chứng minh thư nhân dân','autocomplete'=>'off']); ?>

						    	<small class="text-danger"><?php echo e($errors->first('cmnd')); ?></small>
							</div>
						</div>
						<div class="form-group<?php echo e($errors->has('ngaysinh') ? ' has-error' : ''); ?> row px-2">
						    <?php echo Form::label('ngaysinh', 'Ngày-Tháng-Năm Sinh', ['class' => 'col-sm-3 control-label text-right']); ?>

							<div class="col-sm-9">
						    	<?php echo Form::date('ngaysinh', null, ['class' => 'form-control', 'required' => 'required']); ?>

						    	<small class="text-danger"><?php echo e($errors->first('ngaysinh')); ?></small>
							</div>
						</div>
						
						<div class="form-group<?php echo e($errors->has('sdt') ? ' has-error' : ''); ?> row px-2">
						    <?php echo Form::label('sdt', 'Số điện thoại', ['class' => 'col-sm-3 control-label text-right','autocomplete'=>'off']); ?>

							<div class="col-sm-9">
						    	<?php echo Form::text('sdt', null, ['class' => 'form-control', 'required' => 'required','placeholder'=>'số điện thoại liên hệ']); ?>

						    	<small class="text-danger"><?php echo e($errors->first('sdt')); ?></small>
							</div>
						</div>
						<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> row px-2">
						    <?php echo Form::label('email', 'Email', ['class' => 'col-sm-3 control-label text-right','autocomplete'=>'off']); ?>

							<div class="col-sm-9">
						    	<?php echo Form::email('email', null, ['class' => 'form-control', 'required' => 'required','placeholder'=>'Địa chỉ email']); ?>

						    	<small class="text-danger"><?php echo e($errors->first('email')); ?></small>
							</div>
						</div>
						<div class="form-group<?php echo e($errors->has('noidung') ? ' has-error' : ''); ?> row px-2">
						    <?php echo Form::label('noidung', 'Nội Dung', ['class' => 'col-sm-3 control-label text-right']); ?>

							<div class="col-sm-9">
						    	<?php echo Form::textarea('noidung', null, ['class' => 'form-control', 'required' => 'required','placeholder'=>'Hãy nói gì đó với chúng tôi']); ?>

						    	<small class="text-danger"><?php echo e($errors->first('noidung')); ?></small>
							</div>
						</div>
						<div class="btn-group float-right">
			                <button type="submit" class="btn btn-success">Gửi</button>
			                <button type="reset" class="btn btn-warning">Reset</button>
			            </div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<a class="btn btn-primary float-left " href="#carouselControls" role="button" data-slide="prev" id="btprev" style="display: none;">
		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	</a>
	<a class="btn btn-primary float-right" href="#carouselControls" role="button" data-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
		<span class="sr-only">Next</span>

	</a>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">

	$('#carouselControls').on('slide.bs.carousel', function (e) {
		if($(e.relatedTarget).hasClass('hide_prev'))
		{  					
			$('#btprev').hide();
		}
		else
		{  					
			$('#btprev').show();
		}
	});
</script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.form.min.js')); ?>"></script>
<script type="text/javascript">
	$('#DKNQ').ajaxForm({
        target: '#formlienhe',
        success: function () {
            $('#formlienhe').fadeIn('fast');
            
        }
    });

</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('metatag'); ?>
	<?php echo $__env->make('layout.metatag',compact('cauhinh'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.content', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>