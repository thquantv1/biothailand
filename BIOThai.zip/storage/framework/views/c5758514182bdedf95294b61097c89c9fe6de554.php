<section class="bg-light" id="portfolio">
  <div class="container">
    <div class="row mb-5">
      <div class="col-lg-12 text-center">
        <h2 class="section-heading text-uppercase">sản phẩm</h2>
        <h3 class="section-subheading text-muted">Các sản phẩm tiêu biểu</h3>
        <a class="btn btn-primary" href="<?php echo e(route('dssanpham')); ?>"><i class="fas fa-search-plus"></i><?php echo e(" "); ?>Xem tất cả sản phẩm</a>
      </div>
    </div>
    <div class="row pt-md-5">
      <?php $__currentLoopData = $dssanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <!--Sản phẩm-->
      <div class="col-md-4 col-sm-6 portfolio-item">
        <a class="portfolio-link" href="<?php echo e(route('sanpham',['id'=>$sp->id,'tieude'=>changeTitle($sp->ten)])); ?>">
          <div class="portfolio-hover">
            <div class="portfolio-hover-content">
              <i class="fas fa-plus fa-3x"></i>
            </div>
          </div>
          <img class="img-fluid w-100" src="<?php if($sp->hinh==""): ?><?php echo e(asset('img/no_image.svg')); ?><?php else: ?><?php echo e(asset('upload/sanpham/'.$sp->hinh)); ?><?php endif; ?>" alt="">
        </a>
        <div class="portfolio-caption">
          <h4><?php echo e($sp->ten); ?></h4>
          <p class="text-muted"><?php echo e($sp->loai); ?></p>
        </div>
      </div>
      <!--End Sản phẩm-->
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      
    </div>
  </div>
</section>