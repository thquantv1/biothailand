<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<h2 class="display-4 text-capitalize"><?php echo e($sp->ten); ?></h2>
		<hr class="mx-3">
		<div class="row">
			<div class="col-md-6 col-sm-12 ">
				<img class="item-pic img-thumbnail d-block mx-auto" src="<?php if($sp->hinh==""): ?><?php echo e('img/no_image.svg'); ?><?php else: ?><?php echo e('upload/sanpham/'.$sp->hinh); ?><?php endif; ?>
          " alt="">
			</div>
			<div class="col-md-6 col-sm-12 ">
				<div class="row">
					<p class="font-weight-bold">Qui Cách:&nbsp;</p> 
					<p><?php echo e($sp->quycach); ?></p>
				</div>
				<div class="row">
					<p class="font-weight-bold">Chất Lượng:&nbsp;</p> 
					<p><?php echo e($sp->chatluong); ?></p>
				</div>
				<div class="row">
					<p class="font-weight-bold">Công Dụng:&nbsp;</p> 
					<p><?php echo e($sp->congdung); ?></p>
				</div>
				<div class="row">
					<p class="font-weight-bold">Năng Lực Đáp Ứng:&nbsp;</p> 
					<p><?php echo e($sp->nanglucdapung); ?></p>
				</div>
			</div>
		</div>
		<hr class="mx-3">
		<div class="container-fluid">
			<?php echo $sp->mota; ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('metatag'); ?>
   <?php echo $__env->make('layout.metatag',compact('cauhinh'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.content', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>