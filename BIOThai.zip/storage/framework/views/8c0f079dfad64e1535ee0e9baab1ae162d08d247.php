<?php echo Form::open(['method' => 'POST', 'route' => 'addition_config', 'id'=>'addition_config','class' => 'form-horizontal my-3','files'=>true]); ?>

	<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> row mx-2">
	    <?php echo Form::label('email', 'Địa chỉ Email nhận phản hồi', ['class' => 'col-sm-3 control-label']); ?>

		<div class="col-sm-9">
	    	<?php echo Form::email('email', $cauhinh->valueof('email'), ['class' => 'form-control', 'required' => 'required']); ?>

	    	<small class="text-danger"><?php echo e($errors->first('email')); ?></small>
		</div>
    </div>
    <div class="form-group<?php echo e($errors->has('sdt') ? ' has-error' : ''); ?> row mx-2">
	    <?php echo Form::label('sdt', 'Số điện thoại liên hệ', ['class' => 'col-sm-3 control-label']); ?>

		<div class="col-sm-9">
	    	<?php echo Form::email('sdt', $cauhinh->valueof('sdt'), ['class' => 'form-control', 'required' => 'required']); ?>

	    	<small class="text-danger"><?php echo e($errors->first('sdt')); ?></small>
		</div>
    </div>
    
	<div class="form-group<?php echo e($errors->has('keyword') ? ' has-error' : ''); ?> row mx-2">
	    <?php echo Form::label('keyword', 'Từ Khóa', ['class' => 'col-sm-3 control-label']); ?>

		<div class="col-sm-9">
	    	<?php echo Form::textarea('keyword', $cauhinh->valueof('keyword'), ['class' => 'form-control', 'required' => 'required']); ?>

	    	<small class="text-danger"><?php echo e($errors->first('keyword')); ?></small>
		</div>
	</div>

	<div class="form-group<?php echo e($errors->has('page_description') ? ' has-error' : ''); ?> row mx-2">
	    <?php echo Form::label('page_description', 'Mô tả trang web', ['class' => 'col-sm-3 control-label']); ?>

		<div class="col-sm-9">
	    	<?php echo Form::textarea('page_description', $cauhinh->valueof('page_description'), ['class' => 'form-control', 'required' => 'required']); ?>

	    	<small class="text-danger"><?php echo e($errors->first('page_description')); ?></small>
		</div>
	</div>
	<div class="form-group<?php echo e($errors->has('Search_pagename') ? ' has-error' : ''); ?> row mx-2">
	    <?php echo Form::label('Search_pagename', 'Tên công ty cho các công cụ tìm kiếm', ['class' => 'col-sm-3 control-label']); ?>

		<div class="col-sm-9">
	    	<?php echo Form::text('Search_pagename', $cauhinh->valueof('Search_pagename'), ['class' => 'form-control', 'required' => 'required']); ?>

	    	<small class="text-danger"><?php echo e($errors->first('Search_pagename')); ?></small>
		</div>
	</div>
    
    <div class="form-group<?php echo e($errors->has('page_picture') ? ' has-error' : ''); ?> row mx-2">
         <?php echo Form::label('page_picture', 'Hình đại diện của trang',['class' => 'col-sm-3 control-label']); ?>

         <div class="col-sm-9">
	         <?php echo Form::file('page_picture', ['class' => 'form-control']); ?>

	         <img class="img-responsive col-sm-4" id="page_picture_upload" src="<?php echo e(asset($cauhinh->valueof('page_picture'))); ?>">
	         <small class="text-danger"><?php echo e($errors->first('page_picture')); ?></small>
     	</div>
    </div>
    <div class="btn-group text-right d-flex">
       <?php echo Form::submit("Save", ['class' => 'btn btn-success ml-auto']); ?>

    </div>


<?php echo Form::close(); ?>

<?php $__env->startSection('script'); ?>
	##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
	<script type="text/javascript">		
		$("#page_picture").change(function() {
    		if(checkImage(this))
        		readURL(this,$('#page_picture_upload'));
    		else
        		this.value="";
		});
	</script>
<?php $__env->stopSection(); ?>
