<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<?php if(session('notice')): ?>
		<div class="alert alert-success">
			<?php echo e(session('notice')); ?>

		</div>
		
		<?php endif; ?>
	<div class="row">
		<div class="col-lg-12 clearfix">
			<div class="float-left">
				<h1 class="page-header">Cài đặt
				</h1>
			</div>
		</div>
		<!-- Chổ này là nội dung của phần setting -->
		<div class="container-fluid">
			<ul class="nav nav-pills " id="pills-tab" role="tablist">
			  <li class="nav-item">
			    <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-basic" role="tab" aria-controls="pills-basic" aria-selected="true">Cơ Bản</a>
			  </li>
			  <li class="nav-item">
			    <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-addition" role="tab" aria-controls="pills-addition" aria-selected="false">Nâng Cao</a>
			  </li>
			  
			</ul>
			<div class="tab-content" id="pills-tabContent">
			  <div class="tab-pane fade show active  border border-dark rounded" id="pills-basic" role="tabpanel" aria-labelledby="pills-home-tab"><?php echo $__env->make('admin.cauhinh.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
			  <div class="tab-pane fade border border-dark rounded" id="pills-addition" role="tabpanel" aria-labelledby="pills-profile-tab"><?php echo $__env->make('admin.cauhinh.nangcao', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
			  
			</div>
		</div>

	</div>

	<!-- /.row -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('topscript'); ?>
	<script type="text/javascript" src="<?php echo e(asset('js/configpage.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>