 <section id="services" class="bg-dark ">
    <h class="container-fluid">
     <?php echo Form::open(['method' => 'POST', 'route' => 'checklocation', 'class' => 'form-horizontal','id'=>'check-location']); ?>

      <h2 class="text-center text-uppercase text-white ">
        Kiểm tra địa điểm chưa nhượng quyền
      </h2>
      <div class="text-center text-white mb-4">
        Đã có cửa hàng "Trà Sữa Huy" nhượng quyền tại đây chưa?
      </div>
      <div class="row text-center">

        <div class="form-group<?php echo e($errors->has('matp') ? ' has-error' : ''); ?> row col-md mx-2">
          <?php echo Form::label('matp', 'Tỉnh', ['class' => 'col-sm-3 control-label text-white text-left text-md-right col-form-label']); ?>

          <div class="col-sm-6">
            <?php echo Form::select('matp',$dstinh->sortBy('name')->pluck('name','matp'), null, ['id' => 'matp', 'class' => 'form-control', 'required' => 'required']); ?>

            <small class="text-danger"><?php echo e($errors->first('matp')); ?></small>
          </div>
          <div class="col-sm-2 text-right text-md-left">
          <?php echo Form::submit("Check", ['class' => 'btn btn-success ']); ?>

          </div>
        </div>
      </div>
      <div class="row text-center justify-content-center " >
      <div class="text-white table-responsive col-md-9" id="check-result">

      </div>
      </div>

    <?php echo Form::close(); ?>

    </div>
  </section>

  <section >
    <div class="container-fluid">
    <div class="row">
    <div class="col-xl-3 col-sm-12 ">
      <div class="card card-body h-100 justify-content-start">

      <div class="text-center text-capitalize h4 font-weight-bold">Chuỗi Cửa Hàng Chính</div>
      <div class="count"><p class="number my-auto mx-auto "><?php echo e($cuahangchinh->count()); ?></p></div>
      <table class="mt-3 w-100 table table-bordered" id="dataCHC">
        <thead >
          <th class="w-25 text-center">STT</th>
          <th class="col text-center text-capitalize">Địa Chỉ</th>
        </thead>
        <tbody>
          <?php $__currentLoopData = $cuahangchinh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
            <td class="text-center"><?php echo e($chc->stt); ?></td>
            <td><a href="<?php echo e(route('cuahang',['id'=>$chc->id,'ten'=>$chc->ten])); ?>"><?php echo e($chc->ten); ?><br> <?php echo e($chc->diachi.'-'.$chc->quanhuyen->name.'-'.$chc->quanhuyen->TinhThanhPho->name); ?></a></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      </div>

    </div>
    <div class="col-xl-6 col-sm-12 ">
      <div class="card card-body h-100 justify-content-start">
      <div class="text-center text-capitalize h4 font-weight-bold">Cửa Hàng Nhượng Quyền</div>
      <div class="count"><p class="number my-auto mx-auto"><?php echo e($cuahangnhuongquyen->count()); ?></p></div>
      <table class="mt-3 w-100 table table-bordered" id="dataCHNQ">
        <thead >
          <th class="w-25 text-center">STT</th>
          <th class="col text-center text-capitalize">Địa Chỉ</th>
        </thead>
        <tbody>
           <?php $__currentLoopData = $cuahangnhuongquyen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chnq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
            <td class="text-center"><?php echo e($chnq->stt); ?></td>
            <td><a href="<?php echo e(route('cuahang',['id'=>$chnq->id,'ten'=>$chnq->ten])); ?>"> <?php echo e($chnq->diachi.'-'.$chnq->quanhuyen->name.'-'.$chnq->quanhuyen->TinhThanhPho->name); ?></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    </div>
    <div class="col-xl-3 col-sm-12">
      <div class="card card-body h-100 justify-content-start">
      <div class="text-center text-capitalize h4 font-weight-bold">Đang thương thảo<br>Có thể đăng ký thêm</div>
      <div class="count"><p class="number my-auto mx-auto"><?php echo e($dangkyhd->count()); ?></p></div>
        <table class="mt-3 w-100 table table-bordered" id="dataDKHD">
          <thead >
            <th class="w-25 text-center">STT</th>
            <th class="text-center text-capitalize">Địa Chỉ</th>
            <th class="w-25 text-center text-capitalize">tÌNH TRẠNG</th>
          </thead>
          <tbody>
           <?php $__currentLoopData = $dangkyhd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dkhd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
            <td class="text-center"><?php echo e($dkhd->stt); ?></td>
            <td><a href="#"> <?php echo e($dkhd->diachi.'-'.$dkhd->quanhuyen->name.'-'.$dkhd->quanhuyen->TinhThanhPho->name); ?></a></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
    </div>
  </div>
  </section>
