<?php $__env->startSection('content'); ?>
<!-- Page Content -->

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Dòng Thời Gian
                    <small> - Danh sách</small>
                </h1>
                 <?php if(session('notice')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notice')); ?>

                </div>
                <?php endif; ?>
            </div>
            <!-- /.col-lg-12 -->
            <table class="table table-striped table-bordered table-hover" id="dataTables">
                <thead>
                    <tr align="center">
                        <th>ID</th>
                        <th>Thời Gian</th>
                        <th>Hình Ảnh</th>
                        <th>Sự Kiện</th>
                        <th>Delete</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd gradeX" align="center">
                        <td><?php echo e($tt->id); ?></td>
                        <td><?php echo e($tt->thoigian->format('d-m-Y')); ?><br><?php echo e($tt->tieude); ?></td>
                        <td>
                            <?php if($tt->hinh!=""): ?>
                                <img src="<?php echo e(asset('upload/story/'.$tt->hinh)); ?>" alt="" style="max-width:9rem;">
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($tt->sukien); ?></td>
                        <td class="center"><i class="far fa-trash-alt"></i><a href="<?php echo e(route('Story_delete',[$tt->id])); ?>" onclick="return confirm('Xóa sự kiện này thật sao?');"> Delete</a></td>
                        <td class="center"><i class="fas fa-pencil-alt"></i><a href="<?php echo e(route('Story_edit',[$tt->id])); ?>">Edit</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>