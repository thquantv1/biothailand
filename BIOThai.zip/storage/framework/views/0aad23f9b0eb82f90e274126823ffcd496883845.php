<section id="about">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
				<h2 class="section-heading text-uppercase">Về Chúng Tôi</h2>
				<h3 class="section-subheading text-muted">Quá trình kinh doanh và phát triển</h3>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<ul class="timeline">
                    <?php $__currentLoopData = $story; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="timeline-image">
                                <img class="rounded-circle img-fluid" src="<?php echo e(asset('upload/story/'.$st->hinh)); ?>" alt="" style="height:100%">
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4><?php echo e($st->thoigian->format('d-m-Y')); ?></h4>
                                    <h4 class="subheading"><?php echo e($st->tieude); ?></h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted"><?php echo e($st->sukien); ?></p>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<li class="">
						<div class="timeline-image">
							<h4>Trở Thành
								<br>Một Phần
								<br>Của Chúng Tôi
							</h4>
						</div>
					</li>
				</ul>
				</div>
			</div>
		</div>
</section>
