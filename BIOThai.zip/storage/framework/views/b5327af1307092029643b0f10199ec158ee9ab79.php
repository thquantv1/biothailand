 <header class="masthead" style="background-image: url('<?php echo e($cauhinh->get('bgtrangchu')->value); ?>') ;">
    <div class="container-fluid">
      <div class="intro-text">
        <div class="intro-heading text-uppercase"><?php echo e($cauhinh->get('xinchao2')->value); ?></div>
        <div class="intro-lead-in"><?php echo e($cauhinh->get('xinchao1')->value); ?></div>
         
      </div>
      <div class="row" style="background-color: rgba(0, 0, 0, 0.50);">
        <div class="col-lg-4 col-sm-12 d-flex my-2">
          <table class="mx-auto resizeFont table table-bordered rounded w-100 h-100">
            <tr>
              <th class=" text-capitalize" colspan="2">Chuỗi cửa hàng</th>
            </tr>
            <tr class="text-left">
              <td>Cửa Hàng Chính</td>
              <td><?php echo e($cuahangchinh->count()); ?></td>
            </tr>
            <tr class="text-left">
              <td>Cửa Hàng Nhượng Quyền</td>
              <td><?php echo e($cuahangnhuongquyen->count()); ?></td>
            </tr>
          </table>
        </div>
        <div class="col-lg-4 col-sm-12 d-flex my-2">
          <div class="text-left resizeFont mx-auto border border-white w-100 h-100 d-flex">
            <div class="mx-lg-auto loi-ich" style="">
            <i class="far fa-check-square"></i>.<?php echo e($cauhinh->valueof('loi1')); ?>.<br>
            <i class="far fa-check-square"></i>.<?php echo e($cauhinh->valueof('loi2')); ?>.<br>
            <i class="far fa-check-square"></i>.<?php echo e($cauhinh->valueof('loi3')); ?>

            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-12 d-flex my-2">
         <div class="resizeFont mx-auto border border-white w-100 h-100 d-flex">
          <div class="mx-auto my-auto" style="line-height: 3;">

             SDT/Zalo:
            <a href="tel:<?php echo e($cauhinh->valueof('sdtlienhe')); ?>">
              <h1 class="sdt-zalo"><?php echo e($cauhinh->valueof('sdtlienhe')); ?></h1>
            </a>
           </div>
         </div>
        </div>
    </div>
    </div>
 </header>
