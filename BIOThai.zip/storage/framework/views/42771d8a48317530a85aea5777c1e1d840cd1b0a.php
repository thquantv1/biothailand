<?php $__env->startSection('content'); ?>
<!-- Page Content -->

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Quản Trị viên
                    <small> - Danh sách</small>
                </h1>
                 <?php if(session('notice')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notice')); ?>

                </div>
                <?php endif; ?>
            </div>
            <!-- /.col-lg-12 -->
            <table class="table table-striped table-bordered table-hover" id="dataTables">
                <thead>
                    <tr align="center">
                        <th>ID</th>
                        <th>Tên</th>

                        <th>Email</th>
                        <th>Delete</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $dsuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd gradeX" align="center">
                        <td><?php echo e($tv->id); ?></td>
                        <td><?php echo e($tv->name); ?></td>
                        <td><?php echo e($tv->email); ?></td>

                        <td class="center"><i class="far fa-trash-alt"></i><a href="<?php echo e(route('User_delete',[$tv->id])); ?>" onclick="return confirm('Xóa quản trị viên này thật sao?');"> Delete</a></td>
                        <td class="center"><i class="fas fa-pencil-alt"></i><a href="<?php echo e(route('User_edit',[$tv->id])); ?>">Edit</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>