<?php $__env->startSection('style'); ?>
   <link rel="stylesheet" href="<?php echo e(asset('css/asc_static.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="container mt-2" style="min-height: 65vh;">
        <h2 class="my-4 text-capitalize"><?php echo e($cauhinh->get('tong_quan_cong_ty')->description); ?></h2>
        <hr class="mx-2" />
         <?php echo $cauhinh->get('tong_quan_cong_ty')->value; ?>


	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
   <?php echo e($cauhinh->get('title')->value); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>