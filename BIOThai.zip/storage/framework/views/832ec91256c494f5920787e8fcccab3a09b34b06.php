<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tin Tức
                    <small>Thêm</small>
                </h1>
            </div>
            <!-- /.col-lg-12 -->
            <div class="col-lg-12" style="padding-bottom:120px">
                <?php if(count($errors)>0): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger">
                        <?php echo e($err); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                <?php endif; ?>
                <?php if(session('notice')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notice')); ?>

                </div>
                
                <?php endif; ?>
                <form action="<?php echo e(route('news_add')); ?>" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    
                    <div class="form-group<?php echo e($errors->has('loaitin') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('loaitin', 'Loai Tin', ['class' => ' control-label']); ?>

                        <?php echo Form::select('loaitin', $dsloaitin->pluck('title','id'), null, ['id' => 'loaitin', 'class' => 'form-control', 'required' => 'required','placeholder'=>'Chọn một loại tin']); ?>

                            <small class="text-danger"><?php echo e($errors->first('loaitin')); ?></small>
                    </div>
                    
                    <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('title', 'Tiêu Đề'); ?>

                        <?php echo Form::text('title', null, ['class' => 'form-control', 'required' => 'required']); ?>

                        <small class="text-danger"><?php echo e($errors->first('title')); ?></small>
                    </div>
                    <div class="form-group">
                        <label>Hình ảnh</label>
                        <input id="picture" name="picture" type="file" class="form-control" data-show-preview="false">
                        <img id="photo_review" class="img-responsive img-thumbnail" style="max-width: 25rem;">
                    </div>
                   <div class="form-group<?php echo e($errors->has('summary') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('summary', 'Tóm tắt'); ?>

                        <?php echo Form::textarea('summary', null, ['class' => 'form-control']); ?>

                        <small class="text-danger"><?php echo e($errors->first('summary')); ?></small>
                    </div> 
                    <div class="form-group<?php echo e($errors->has('content') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('content', 'Nội dung'); ?>

                        <?php echo Form::textarea('content', null, ['class' => 'form-control ckeditor']); ?>

                        <small class="text-danger"><?php echo e($errors->first('content')); ?></small>
                    </div>
                    <div class="form-group">
                        <label>Nổi Bật?</label>
                        <label class="radio-inline">
                            <input name="highlight" value="1" checked="" type="radio">Có
                        </label>
                        <label class="radio-inline">
                            <input name="highlight" value="0" type="radio">Không
                        </label>
                    </div>
                    <div class="btn-group float-right">
                    <button type="submit" class="btn btn-success">Add</button>
                    <button type="reset" class="btn btn-warning">Reset</button>
                </div>
                <form>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script >
    $(document).ready(function()
    {
        
        $("#picture").change(function()
        {
            if(checkImage(this))
                 readURL(this,$('#photo_review'));
            else
             this.value="";

        });
    });
    
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>