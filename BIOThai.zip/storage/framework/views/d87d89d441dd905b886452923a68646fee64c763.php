<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<h2 class="display-4 text-capitalize"><?php echo e($ch->ten); ?></h2>
		<hr class="mx-3">
		<div class="row">
			<div class="col-md-6 col-sm-12 ">
				<img class="item-pic img-thumbnail d-block mx-auto" src="<?php if($ch->hinh==""): ?><?php echo e('img/no_image.svg'); ?><?php else: ?><?php echo e('upload/cuahang/'.$ch->hinh); ?><?php endif; ?>
          " alt="">
			</div>
			<div class="col-md-6 col-sm-12 ">
				<div class="row">
					<p class="font-weight-bold">Loại:&nbsp;</p> 
					<p><?php echo e(loaich()[$ch->loai]); ?></p>
				</div>
				<div class="row">
					<p class="font-weight-bold">Địa chỉ:&nbsp;</p> 
					<p><?php echo e($ch->diachi.'-'.$ch->quanhuyen->name.'-'.$ch->quanhuyen->TinhThanhPho->name); ?></p>
				</div>
				<div class="row">
					<p class="font-weight-bold">Số điện thoại:&nbsp;</p> 
					<p><?php echo e($ch->sdt); ?></p>
				</div>
			</div>
		</div>
		<hr class="mx-3">
		<div class="container-fluid">
			<?php echo $ch->thongtin; ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('metatag'); ?>
   <?php echo $__env->make('layout.metatag',compact('cauhinh'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.content', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>