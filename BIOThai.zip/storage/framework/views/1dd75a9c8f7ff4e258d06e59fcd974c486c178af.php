<?php echo Form::open(['method' => 'POST', 'route' => 'basic_config', 'id'=>'basic_config','class' => 'form-horizontal my-3','files'=>true]); ?>

	<div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?> row mx-2">
	    <?php echo Form::label('title', 'Title', ['class' => 'col-sm-3 control-label']); ?>

		<div class="col-sm-9">
	    	<?php echo Form::text('title', $cauhinh->valueof('title'), ['class' => 'form-control', 'required' => 'required']); ?>

	    	<small class="text-danger"><?php echo e($errors->first('title')); ?></small>
		</div>
	</div>
	<div class="form-group<?php echo e($errors->has('tencty') ? ' has-error' : ''); ?> row mx-2">
	    <?php echo Form::label('tencty', 'Tên Công Ty', ['class' => 'col-sm-3 control-label']); ?>

		<div class="col-sm-9">
	    	<?php echo Form::text('tencty', $cauhinh->valueof('tencty'), ['class' => 'form-control', 'required' => 'required']); ?>

	    	<small class="text-danger"><?php echo e($errors->first('tencty')); ?></small>
		</div>
	</div>
	<div class="form-group<?php echo e($errors->has('tencty_daydu') ? ' has-error' : ''); ?> row mx-2">
	    <?php echo Form::label('tencty_daydu', 'Tên Công Ty Đầy Đủ', ['class' => 'col-sm-3 control-label']); ?>

		<div class="col-sm-9">
	    	<?php echo Form::text('tencty_daydu', $cauhinh->valueof('tencty_daydu'), ['class' => 'form-control', 'required' => 'required']); ?>

	    	<small class="text-danger"><?php echo e($errors->first('tencty_daydu')); ?></small>
		</div>
	</div>
	
    <div class="form-group<?php echo e($errors->has('logo') ? ' has-error' : ''); ?> row mx-2">
         <?php echo Form::label('logo', 'Logo công ty',['class' => 'col-sm-3 control-label']); ?>

         <div class="col-sm-9">
	         <?php echo Form::file('logo', ['class' => 'form-control']); ?>

	         <img class="logo rounded img-responsive col-sm-4" id="logo_upload" src="<?php echo e(asset($cauhinh->valueof('logo'))); ?>">
	         <small class="text-danger"><?php echo e($errors->first('logo')); ?></small>
     	</div>
    </div> 
    
    <div class="btn-group text-right d-flex">
       <?php echo Form::submit("Save", ['class' => 'btn btn-success ml-auto']); ?>

    </div>
<?php echo Form::close(); ?>

<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
	<script type="text/javascript">
		$("#logo").change(function() {
    		if(checkImage(this))
        		readURL(this,$('#logo_upload'));
    		else
        		this.value="";  
	});
	</script>
<?php $__env->stopSection(); ?>