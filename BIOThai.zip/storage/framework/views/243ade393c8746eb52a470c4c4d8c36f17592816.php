<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Trà Sữa Huy - <?php echo $__env->yieldContent('page_description'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset($cauhinh->get('logo')->value)); ?>">
    <title>Trà Sữa Huy - <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/agency.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/asc_static.css')); ?>">
    <link href="<?php echo e(asset('fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <base href="<?php echo e(asset('')); ?>">
    <?php echo $__env->yieldContent('metatag'); ?>

    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
      <?php echo $__env->make('layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="container-fluid">
          <div class="jumbotron jumbotron-fluid">
              <div class="container">
                  <?php echo $__env->yieldContent('content'); ?>
              </div>
          </div>
      </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>

