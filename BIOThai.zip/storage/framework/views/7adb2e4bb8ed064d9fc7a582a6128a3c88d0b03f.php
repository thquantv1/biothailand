<table class="table table-bordered table-striped">
	<tbody>
		<?php $__currentLoopData = $tinh->QuanHuyen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
		<tr>      
				<td><?php echo e($qh->name); ?></td>
				<td>
					<?php
					$ch=$qh->cuahang->first();
					$tthd=$ch['tthd'];
					?>
					<?php if($tthd==1||$tthd==2||$tthd==3): ?>
						<?php echo e(tinhtranghd()[$tthd]); ?>					
					<?php else: ?>					
						<a href="dangkynhuongquyen/<?php echo e($qh->maqh); ?>">Đăng ký nhượng quyền tại đây</a>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>