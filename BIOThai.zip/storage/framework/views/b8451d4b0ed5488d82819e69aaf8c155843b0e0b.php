<section id="contact" style="">
  <div class="container text-white text-center">
    <h1 class="text-uppercase">Gọi ngay cho chúng tôi </h1>
    <h1 class="text-uppercase">theo số điện thoại</h1>
    <a href="tel:<?php echo e($cauhinh->valueof('sdtlienhe')); ?>">
      <h1 class="font-weight-bold sdt"><?php echo e($cauhinh->valueof('sdtlienhe')); ?></h1>
    </a>
  </div>
  <div class="container" id="form-lien-he" style="display:none;">
    <div class="row mb-4">
      <div class="col-lg-12 text-center">
        <h2 class="section-heading text-uppercase">Liên hệ với chúng tôi</h2>
        <h3 class="section-subheading text-danger " id="thongbao"></h3>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12">
        <form id="contactForm" name="sentMessage" novalidate="novalidate" method="POST" action="<?php echo e(route('sendMail')); ?>">
          <?php echo csrf_field(); ?>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <input class="form-control" name="name" id="name" type="text" placeholder="Your Name *" required="required" data-validation-required-message="Please enter your name.">
                <p class="help-block text-danger"></p>
              </div>
              <div class="form-group">
                <input class="form-control" name="email" id="email" type="email" placeholder="Your Email *" required="required" data-validation-required-message="Please enter your email address.">
                <p class="help-block text-danger"></p>
              </div>
              <div class="form-group">
                <input class="form-control" name="phone" id="phone" type="tel" placeholder="Your Phone *" required="required" data-validation-required-message="Please enter your phone number.">
                <p class="help-block text-danger"></p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <textarea class="form-control" name="message" id="message" placeholder="Your Message *" required="required" data-validation-required-message="Please enter a message."></textarea>
                <p class="help-block text-danger"></p>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="col-lg-12 text-center">
              <div id="success"></div>
              <button id="sendMessageButton" class="btn btn-primary btn-xl text-uppercase" type="submit">Send Message</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
