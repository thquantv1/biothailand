<nav id="sidebar" >
    <div class="sidebar-header">
        <h3>BIO THAILAND</h3>
    </div>
    <ul class="list-unstyled components">
        <p>Trang quản trị</p>
        <li>
            <a href="#loaisanphamSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fas fa-wine-glass-alt"></i>
            Loại Sản Phẩm</a>
            <ul class="collapse list-unstyled" id="loaisanphamSubmenu">
                <li>
                    <a href="<?php echo e(route('Catalog_list')); ?>"><i class="fas fa-list"></i>Danh sách</a>
                </li>
                <li>
                    <a href="<?php echo e(route('Catalog_add')); ?>"><i class="fas fa-plus"></i>Thêm</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="#sanphamSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fas fa-wine-glass-alt"></i>
            Sản Phẩm</a>
            <ul class="collapse list-unstyled" id="sanphamSubmenu">
                <li>
                    <a href="<?php echo e(route('SanPham_list')); ?>"><i class="fas fa-list"></i>Danh sách</a>
                </li>
                <li>
                    <a href="<?php echo e(route('SanPham_add')); ?>"><i class="fas fa-plus"></i>Thêm</a>
                </li>
            </ul>
        </li>

        <li>
            <a href="#staticSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="far fa-file-alt"></i>
            Trang tĩnh</a>
            <ul class="collapse list-unstyled" id="staticSubmenu">
                <li>
                    <a href="<?php echo e(route('StaticPage_list')); ?>"><i class="fas fa-list"></i>Danh sách</a>
                </li>
                <li>
                    <a href="<?php echo e(route('StaticPage_add')); ?>"><i class="fas fa-plus"></i>Thêm</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="#newstypeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="far fa-newspaper"></i>
            Loại Tin</a>
            <ul class="collapse list-unstyled" id="newstypeSubmenu">
                <li>
                    <a href="<?php echo e(route('NewsType_list')); ?>"><i class="fas fa-list"></i>Danh sách</a>
                </li>
                <li>
                    <a href="<?php echo e(route('NewsType_add')); ?>"><i class="fas fa-plus"></i>Thêm</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="#newsSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="far fa-newspaper"></i>
            Tin Tức</a>
            <ul class="collapse list-unstyled" id="newsSubmenu">
                <li>
                    <a href="<?php echo e(route('news_list')); ?>"><i class="fas fa-list"></i>Danh sách</a>
                </li>
                <li>
                    <a href="<?php echo e(route('news_add')); ?>"><i class="fas fa-plus"></i>Thêm</a>
                </li>
            </ul>
        </li>

        <a class="ml-1" href="<?php echo e(route('pageconfig')); ?>"><i class="fas fa-cogs"></i> Cài đặt</a>
        <li>
            <a href="#userSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-users"></i>
            Quản Trị Viên</a>
            <ul class="collapse list-unstyled" id="userSubmenu">
                <li>
                    <a href="<?php echo e(route('User_list')); ?>"><i class="fas fa-list"></i>Danh sách</a>
                </li>
                <li>
                    <a href="<?php echo e(route('User_add')); ?>"><i class="fas fa-plus"></i>Thêm</a>
                </li>
            </ul>
        </li>
        
    </ul>
</nav>
