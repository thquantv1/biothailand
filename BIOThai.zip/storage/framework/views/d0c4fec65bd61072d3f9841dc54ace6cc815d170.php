<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Trà Sữa Huy - <?php echo $__env->yieldContent('page_description'); ?>">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Trà Sữa Huy - <?php echo $__env->yieldContent('title'); ?></title>
  <?php echo $__env->yieldContent('metatag'); ?>

  <base href="<?php echo e(asset('')); ?>">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">
  <!-- Custom fonts for this template -->
  <link href="<?php echo e(asset('fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
  <link rel="icon" href="<?php echo e(asset($cauhinh->get('logo')->value)); ?>">
  <!-- Datatables CSS -->
    <link rel="stylesheet" type="text/css" href="lib/datatables/datatables.min.css"/>
  <!-- Styles -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
  <link href="<?php echo e(asset('css/agency.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body id="page-top">
  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
    <div class="container-fluid">
      <a class="navbar-brand js-scroll-trigger text-uppercase" href="#page-top">
        <img src="<?php echo e($cauhinh->get('logo')->value); ?>" alt="Trà Sữa Huy">
        Trà Sữa huy
      </a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#services">Nhượng Quyền</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#portfolio">Sản Phẩm</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#about">Về Chúng Tôi</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#team">Các Thành Viên</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#contact">Liên Hệ</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<?php echo $__env->yieldContent('content'); ?>



  <script>
    (function (d, s, id)
    {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
  </script>

  <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/jquery-easing/jquery.easing.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/agency.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/jqBootstrapValidation.js')); ?>"></script>
  <script type="text/javascript" src="lib/datatables/datatables.min.js"></script>
  <script type="text/javascript">

  </script>
  <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
