<?php $__env->startSection('style'); ?>
   <link rel="stylesheet" href="<?php echo e(asset('css/asc_static.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mb-3" style="min-height: 65vh;">
	<div class="col-lg-12">
          <h2 class="my-4 text-capitalize"><?php echo e($tieude); ?></h2>
    </div>
        <hr class="mx-2">
	<div class="row ">
				<?php if($dstintuc->count() == 0): ?>
					<div class="">Chưa có có tin tức.</div>
				<?php endif; ?>

        <?php $__currentLoopData = $dstintuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row col-md-12">
	        <div class="col-md-5">
	          <a href="<?php echo e(route('tintuc',['id'=>$tt->id,'tieude'=>changeTitle($tt->title)])); ?>">
	            <img class="img-fluid rounded mb-3 mb-md-0" src="<?php if($tt->picture==""): ?><?php echo e('img/no_image.svg'); ?><?php else: ?><?php echo e('upload/news/'.$tt->picture); ?><?php endif; ?>" alt="">
	          </a>
	        </div>
	        <div class="col-md-7">
	          <h3><?php echo e($tt->title); ?></h3>
	          <p><?php echo e($tt->summary); ?></p>
	          <a class="btn btn-primary" href="<?php echo e(route('tintuc',['id'=>$tt->id,'tieude'=>changeTitle($tt->title)])); ?>">Tìm Hiểu Thêm</a>
	        </div>
      	</div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
		<div class="d-flex justify-content-center "><?php echo e($dstintuc->links()); ?></div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
   <?php echo e($cauhinh->get('title')->value); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>