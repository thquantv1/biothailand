<?php $__env->startSection('content'); ?>
	<div class="col-lg-12">
          <h2 class="my-4 text-capitalize">Các Sản Phẩm</h2>
    </div>
        <hr class="mx-2">
	<div class="row ">
        <?php $__currentLoopData = $dssanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <!--sản phẩm nè-->
        <a class="col-lg-4 col-sm-6 text-center mb-4" href="<?php echo e(route('sanpham',['id'=>$sp->id,'tieude'=>changeTitle($sp->ten)])); ?>">

          <img class="rounded-item rounded-circle img-fluid d-block mx-auto" src="<?php if($sp->hinh==""): ?><?php echo e('img/no_image.svg'); ?><?php else: ?><?php echo e('upload/sanpham/'.$sp->hinh); ?><?php endif; ?>
          " width="300" height="300" alt="">
          <h3><?php echo e($sp->ten); ?>

            
          </h3>
          <p>Giá:<?php echo e($sp->gia); ?></p>

        </a>
        <!--hết phần của sản phẩm nè-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="d-flex justify-content-center "><?php echo e($dssanpham->links()); ?></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('metatag'); ?>
   <?php echo $__env->make('layout.metatag',compact('cauhinh'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.content', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>