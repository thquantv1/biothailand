<?php

use Faker\Generator as Faker;

$factory->define(App\ThanhVien::class, function (Faker $faker) {
    return [
        //
    ];
});
