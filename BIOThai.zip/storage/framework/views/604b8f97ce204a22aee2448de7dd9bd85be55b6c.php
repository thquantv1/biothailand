<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 clearfix">
                <h1 class="page-header float-left">Loại Tin
                    <small>Danh sách</small>
                </h1>
                <div class="float-right"><a class="btn btn-success pull-right" href="<?php echo e(route('Catalog_add')); ?>"><i class="fa fa-plus"></i> </a></div>
                <?php if(session('notice')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notice')); ?>

                </div>

                <?php endif; ?>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover" id="dataTables">
                    <thead>
                        <tr align="center">
                            <th>Stt</th>
                            <th>Tên Loại Sản Phẩm</th>
                            <th>Số lượng sản phẩm</th>
                            <th>Delete</th>
                            <th>Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dscatalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="odd gradeX" align="center">
                            <td><?php echo e($nt->id); ?></td>
                            <td><?php echo e($nt->name); ?></td>
                            <td><?php echo e($nt->SanPham->count()); ?></td>
                            <td class="center"><i class="far fa-trash-alt"></i><a href="<?php echo e(route('Catalog_delete',[$nt->id])); ?> "
                                onclick="return confirm('Xóa loại tin này thật sao?');"> Delete</a></td>
                            <td class="center"><i class="fas fa-pencil-alt"></i><a href="<?php echo e(route('Catalog_edit',[$nt->id])); ?>">Edit</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready( function () {
            $('#dataTables').DataTable();
        } );
    </script>
    
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>