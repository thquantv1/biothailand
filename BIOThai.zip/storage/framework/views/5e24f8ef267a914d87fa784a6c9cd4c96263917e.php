<section id="news-card">
  <div class="container">
    <div class="row mb-5">
      <div class="col-lg-12 text-center">
        <h2 class="section-heading text-uppercase">Tin tức</h2>
        <h3 class="section-subheading text-muted">Các tin mới</h3>
        <a class="btn btn-primary" href="<?php echo e(route('dstintuc')); ?>"><i class="fas fa-search-plus"></i><?php echo e(" "); ?>Xem tất cả
        </a>
      </div>
    </div>
    <div class="row text-center">
      <?php $__currentLoopData = $dstintuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 mb-4">
        <div class="card">
          <img class="card-img-top" src="<?php if($tt->picture==""): ?><?php echo e(asset('img/no_image.svg')); ?><?php else: ?><?php echo e(asset('upload/news/'.$tt->picture)); ?><?php endif; ?>" alt="">
          <div class="card-body">
            <h4 class="card-title"><?php echo e($tt->title); ?></h4>
            <p class="card-text"><?php echo e(str_limit($tt->summary, $limit = 80, $end = '...')); ?></p>
          </div>
          <div class="card-footer">
            <a href="<?php echo e(route('tintuc',['id'=>$tt->id,'tieude'=>changeTitle($tt->title)])); ?>" class="btn btn-primary">Xem tiếp...</a>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </div>
</section>
