<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tin tức
                    <small>Danh sách</small>
                </h1>
                 <?php if(session('notice')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notice')); ?>

                </div>
                
                <?php endif; ?>
            </div>
            <!-- /.col-lg-12 -->
            <table class="table table-striped table-bordered table-hover" id="dataTables">
                <thead>
                    <tr align="center">
                        <th>ID</th>
                        <th>Tiêu Đề</th>
                        <th>Tóm Tắt</th>
                        <th>Nổi Bật</th>
                        <th>Số Lượt Xem</th>
                        <th>Ngày tạo</th>
                        <th>Delete</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd gradeX" align="center">
                        <td><?php echo e($tt->id); ?></td>
                        <td><p><?php echo e($tt->title); ?></p>
                            <img src="upload/news/<?php echo e($tt->picture); ?>" class="img-thumbnail" style="max-width: 150px;">
                        </td>
                        <td><?php echo e(str_limit($tt->summary,150)); ?></td>
                        
                        <td><?php if($tt->highlight==0): ?>
                            <?php echo e("Không"); ?>

                        <?php else: ?>
                            <?php echo e("Có"); ?>

                        <?php endif; ?></td>
                        <td><?php echo e($tt->viewCount); ?></td>
                        <td><?php echo e($tt->created_at); ?></td>
                        
                        <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="<?php echo e(route('news_delete',[$tt->id])); ?>"> Delete</a></td>
                        <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="<?php echo e(route('news_edit',[$tt->id])); ?>">Edit</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>