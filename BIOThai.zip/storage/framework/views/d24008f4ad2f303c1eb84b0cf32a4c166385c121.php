<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Trà Sữa Huy - Quản trị</title>
    <base href="<?php echo e(asset('')); ?>">
    <link rel="icon" href="<?php echo e(asset('img/HuyLogo.jpg')); ?>">
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/asc_custom.css')); ?>">
    <!-- Datatables CSS -->
    <link rel="stylesheet" type="text/css" href="lib/datatables/datatables.min.css"/>
    <?php echo $__env->yieldContent('style'); ?>
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
     <!-- CKEditor-->
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('lib/ckeditor/ckeditor.js')); ?>" ></script>


</head>

<body>

    <div class="wrapper">
        <!-- Sidebar Holder -->
        <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Page Content Holder -->
        <div id="content">
            <?php echo $__env->make('admin.layout.topmenu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>

        </div>
    </div>


    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/asc_custom.js')); ?>"></script>
    <script type="text/javascript" src="lib/datatables/datatables.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.form.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('topscript'); ?>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
