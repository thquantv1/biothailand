<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div class="container-fluid">
	<?php if(session('notice')): ?>
		<div class="alert alert-success">
			<?php echo e(session('notice')); ?>

		</div>
		
		<?php endif; ?>
	<div class="row">
		<div class="col-lg-12 clearfix">
			<div class="float-left"><h1 class="page-header">Deep setting
				<small>List</small>
			</h1></div>
			<div class="float-right"><a class="btn btn-success pull-right" href="admin/setting/add"><i class="fa fa-plus"></i> Add new field</a></div>
		</div>
		<div class="table-responsive">
		<table class="table table-striped table-bordered table-hover" id="dataTables">
			<thead>
				<tr align="center">
					<th>ID</th>
					<th>Key Name</th>
					<th>Value</th>
					<th>Desciption</th>
					<th>Delete</th>
					<th>Edit</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $deepset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr class="odd gradeX" align="center">
					<td><?php echo e($ds->id); ?></td>
					<td><?php echo e($ds->keyname); ?></td>
					<td><?php echo e(str_limit($ds->value,50)); ?></td>
					<td><?php echo e($ds->description); ?></td>
					<td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="admin/setting/delete/<?php echo e($ds->id); ?>" onclick="return confirm('Xóa cấu hình này thật sao?');"> Delete</a></td>
					<td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="admin/setting/edit/<?php echo e($ds->id); ?>">Edit</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		</div>
	</div>
	<!-- /.row -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready( function () {
            $('#dataTables').DataTable();
        } );
    </script>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>