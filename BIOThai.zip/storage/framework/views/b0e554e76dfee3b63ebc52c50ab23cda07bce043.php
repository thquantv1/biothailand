<?php $__env->startSection('content'); ?>
<h1 class="display-4"><?php echo e($page->tieude); ?></h1>
<hr class="my-2">
<p class="lead">
    <?php echo e($page->tomtat); ?>

</p>
<hr class="my-2">
<?php echo $page->noidung; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('metatag'); ?>
   <?php echo $__env->make('layout.metatag',compact('cauhinh'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.content', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>