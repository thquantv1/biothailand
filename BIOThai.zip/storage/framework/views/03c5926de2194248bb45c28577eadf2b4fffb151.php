
<meta name="description" content="<?php echo e($cauhinh->valueof('page_description')); ?>">
<meta name="keywords" content="<?php echo e($cauhinh->valueof('keyword')); ?>">

<!-- Google / Search Engine Tags -->
<meta itemprop="name" content="<?php echo e($cauhinh->valueof('Search_pagename')); ?>">
<meta itemprop="description" content="<?php echo e($cauhinh->valueof('page_description')); ?>">
<meta itemprop="image" content="<?php echo e(asset($cauhinh->valueof('page_picture'))); ?>">

<!-- Facebook Meta Tags -->
<meta property="og:url" content="<?php echo e(asset('')); ?>">
<meta property="og:type" content="website">
<meta property="og:title" content="<?php echo e($cauhinh->valueof('title')); ?>">
<meta property="og:description" content="<?php echo e($cauhinh->valueof('page_description')); ?>">
<meta property="og:image" content="<?php echo e(asset($cauhinh->valueof('page_picture'))); ?>">

<!-- Twitter Meta Tags -->
<meta name="twitter:card" content="<?php echo e($cauhinh->valueof('Search_pagename')); ?>">
<meta name="twitter:title" content="<?php echo e($cauhinh->valueof('title')); ?>">
<meta name="twitter:description" content="<?php echo e($cauhinh->valueof('page_description')); ?>">
<meta name="twitter:image" content="<?php echo e(asset($cauhinh->valueof('page_picture'))); ?>">
