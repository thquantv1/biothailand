<footer>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-4">
          <span class="copyright">Copyright &copy; Trà Sữa Huy</span>
        </div>
        <div class="col-md-4 align-baseline">
          <div class="fb-share-button" data-href="https://www.trasuahuy.vn" data-layout="button_count">
          </div>
        </div>
        <div class="col-md-4">
          <ul class="list-inline quicklinks">
            <li class="list-inline-item">
              <a href="#">Design by congnghesoasc.com</a>
            </li>
           
          </ul>
        </div>
      </div>
    </div>
  </footer>
