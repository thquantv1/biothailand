<section id="services-guide">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h2 class="section-heading text-uppercase">Nhượng quyền trà sữa huy</h2>
        <h3 class="section-subheading text-muted">Đăng ký nhượng quyền trà sữa</h3>
      </div>
    </div>
    <div class="row text-center">
      <div class="col-md-4">
        <a href="<?php echo e(route('trangdon', ['id'=>$why->id,'tieude'=>$why->tieudekhongdau])); ?>">
            <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-question fa-stack-1x fa-inverse"></i>
            </span>
        </a>
        <h4 class="service-heading text-capitalize"><?php echo e($why->tieude); ?></h4>
        <p class="text-muted"><?php echo e($why->tomtat); ?></p>
      </div>
      <div class="col-md-4">
        <a href="<?php echo e(route('trangdon', ['id'=>$benifit->id,'tieude'=>$benifit->tieudekhongdau])); ?>">
            <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-dollar-sign fa-stack-1x fa-inverse"></i>
            </span>
        </a>
        <h4 class="service-heading text-capitalize"><?php echo e($benifit->tieude); ?></h4>
        <p class="text-muted"><?php echo e($benifit->tomtat); ?></p>
      </div>
      <div class="col-md-4">
        <a href="<?php echo e(route('trangdon', ['id'=>$method->id,'tieude'=>$method->tieudekhongdau])); ?>">
            <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="far fa-handshake fa-stack-1x fa-inverse"></i>
            </span>
        </a>
        <h4 class="service-heading"><?php echo e($method->tieude); ?></h4>
        <p class="text-muted"><?php echo e($method->tomtat); ?></p>
      </div>
    </div>
  </div>
</section>
