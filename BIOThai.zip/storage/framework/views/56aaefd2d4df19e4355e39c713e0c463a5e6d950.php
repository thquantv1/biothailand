<?php $__env->startSection('content'); ?>
     <!-- Header -->
    <?php echo $__env->make('trangchu.intro', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Portfolio Grid -->
    <?php echo $__env->make('trangchu.portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- hight light news -->
    <?php echo $__env->make('trangchu.news', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- About -->
     
    <!-- Team -->
    
    <!-- Contact -->
    <?php echo $__env->make('trangchu.contact', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('trangchu.currency', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Portfolio Modals -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.form.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/trangchu.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('metatag'); ?>
   <?php echo $__env->make('layout.metatag',compact('cauhinh'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
   <?php echo e($cauhinh->get('title')->value); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>